/*
Brandon Danielski
2/14/2017
CS202
Assignment 3
This is the .h file for the app of the program.  It controls all user interaction.
*/
#include"tree.h"
#ifndef APP_H
#define APP_H
class app
{
	public:
		void first_greeting();//Greets the user when starting the program.
		void main_menu(tree& main_tree);//The main menu for the user to user the program.
	private:
};
#endif
